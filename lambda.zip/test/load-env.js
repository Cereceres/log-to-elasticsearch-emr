module.exports = () => {
    process.env.ES_HOST = 'localhost:9200';
};
